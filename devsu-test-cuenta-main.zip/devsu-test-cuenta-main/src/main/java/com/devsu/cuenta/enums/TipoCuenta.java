package com.devsu.cuenta.enums;

public enum TipoCuenta {
    AHORROS,
    CORRIENTE

}
