package com.devsu.test.handlerException.exception;

public class AlreadyExistsException extends Exception{
    public AlreadyExistsException(String message) {
        super(message);
    }

}
